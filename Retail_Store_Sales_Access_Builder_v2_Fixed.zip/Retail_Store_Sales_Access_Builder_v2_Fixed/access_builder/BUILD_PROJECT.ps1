﻿#requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
try { Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue } catch {}

$AC_FORM = 2
$AC_REPORT = 3
$AC_MODULE = 5
$AC_DESIGN = 1
$AC_NORMAL = 0
$AC_SAVE_YES = 1
$AC_FORM_ADD = 0
$AC_VIEW_PREVIEW = 2
$AC_DETAIL = 0
$AC_HEADER = 1
$AC_FOOTER = 2
$AC_TEXTBOX = 109
$AC_LABEL = 100
$AC_BUTTON = 104
$AC_COMBO = 111
$AC_SUBFORM = 112
$AC_RECT = 101
$AC_CMD_FORM_HDR_FTR = 36
$AC_CMD_REPORT_HDR_FTR = 37
$AC_CMD_COMPILE_SAVE_ALL = 126
$DB_FAIL_ON_ERROR = 128
$DB_REL_UPDATE_CASCADE = 256
$DB_TEXT = 10
$DB_BOOLEAN = 1

$script:BuilderDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:OutputDir = Join-Path $script:BuilderDir 'output'
$script:BuildDir = Join-Path $script:BuilderDir 'build'
$script:LogPath = Join-Path $script:BuilderDir 'BUILD_LOG.txt'
$script:TempDbPath = Join-Path $script:BuildDir 'RetailSalesSystem_build.accdb'
$script:FinalDbPath = Join-Path $script:OutputDir 'نظام_إدارة_مبيعات_محل_تجاري.accdb'
$script:Phase = 'Bootstrap'
$script:CurrentObject = ''
$script:App = $null
$script:Db = $null
$script:BuildSucceeded = $false
$script:Stats = [ordered]@{ Tables=0; Relationships=0; Queries=0; Forms=0; Subforms=0; Reports=0; SampleRecords=0 }

New-Item -ItemType Directory -Force -Path $script:OutputDir | Out-Null
New-Item -ItemType Directory -Force -Path $script:BuildDir | Out-Null
if (Test-Path -LiteralPath $script:LogPath) { Remove-Item -LiteralPath $script:LogPath -Force }

function Write-Log {
    param([Parameter(Mandatory=$true)][string]$Message)
    $line = '{0:yyyy-MM-dd HH:mm:ss.fff} | {1}' -f (Get-Date), $Message
    [System.IO.File]::AppendAllText($script:LogPath, $line + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($true)))
}

function Set-Context { param([string]$ObjectName) $script:CurrentObject = $ObjectName; Write-Log ('Object: ' + $ObjectName) }

function Start-Phase {
    param([string]$Name)
    $script:Phase = $Name
    $script:CurrentObject = ''
    Write-Log ''
    Write-Log ('[' + $Name + ']')
}

function Release-ComObjectSafe {
    param($Object)
    if ($null -ne $Object -and [System.Runtime.InteropServices.Marshal]::IsComObject($Object)) {
        try { [void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($Object) } catch {}
    }
}

function Stop-AccessSafe {
    try { if ($null -ne $script:Db) { Release-ComObjectSafe $script:Db; $script:Db = $null } } catch {}
    if ($null -ne $script:App) {
        try { $script:App.CloseCurrentDatabase() } catch {}
        try { $script:App.Quit() } catch {}
        try { Release-ComObjectSafe $script:App } catch {}
        $script:App = $null
    }
    [GC]::Collect(); [GC]::WaitForPendingFinalizers(); [GC]::Collect(); [GC]::WaitForPendingFinalizers()
}

function Invoke-Sql {
    param([Parameter(Mandatory=$true)][string]$Sql,[string]$ObjectName='SQL')
    Set-Context $ObjectName
    $script:Db.Execute($Sql, $DB_FAIL_ON_ERROR)
    Write-Log ($ObjectName + ': OK')
}

function Save-Query {
    param([string]$Name,[string]$Sql)
    Set-Context $Name
    try { $script:Db.QueryDefs.Delete($Name) } catch {}
    $q = $script:Db.CreateQueryDef($Name,$Sql)
    Release-ComObjectSafe $q
    $script:Stats.Queries++
    Write-Log ($Name + ': OK')
}

function Escape-SqlText { param([string]$Value) return $Value.Replace("'","''") }

function Set-DbProperty {
    param([string]$Name,[int]$Type,$Value)
    Set-Context ('Database property ' + $Name)
    try { $script:Db.Properties.Item($Name).Value = $Value }
    catch {
        $p = $script:Db.CreateProperty($Name,$Type,$Value)
        $script:Db.Properties.Append($p)
        Release-ComObjectSafe $p
    }
    Write-Log ($Name + ': OK')
}

function New-BaseForm {
    param([string]$Name,[string]$Caption,[int]$Width,[int]$Height=8500)
    Set-Context $Name
    $frm = $script:App.CreateForm()
    $temp = $frm.Name
    $frm.Caption = $Caption
    $frm.Width = $Width
    $frm.Section($AC_DETAIL).Height = $Height
    $frm.Section($AC_DETAIL).BackColor = 16448250
    $frm.NavigationButtons = $false
    $frm.RecordSelectors = $false
    $frm.DividingLines = $false
    $frm.AutoCenter = $true
    $frm.ScrollBars = 0
    $script:App.DoCmd.Save($AC_FORM,$temp)
    $script:App.DoCmd.Close($AC_FORM,$temp,$AC_SAVE_YES)
    $script:App.DoCmd.Rename($Name,$AC_FORM,$temp)
    $script:App.DoCmd.OpenForm($Name,$AC_DESIGN)
    Release-ComObjectSafe $frm
    $result = $script:App.Forms.Item($Name)
    return $result
}

function Close-SaveForm { param([string]$Name) $script:App.DoCmd.Save($AC_FORM,$Name); $script:App.DoCmd.Close($AC_FORM,$Name,$AC_SAVE_YES); Write-Log ($Name + ': SAVED') }

function Add-Rectangle {
    param([string]$Form,[int]$X,[int]$Y,[int]$W,[int]$H,[int]$BackColor,[int]$BorderColor=15132390)
    $c=$script:App.CreateControl($Form,$AC_RECT,$AC_DETAIL,'','',$X,$Y,$W,$H)
    $c.BackStyle=1; $c.BackColor=$BackColor; $c.BorderColor=$BorderColor; $c.SpecialEffect=0
    Release-ComObjectSafe $c
}

function Add-Label {
    param([string]$Form,[string]$Caption,[int]$X,[int]$Y,[int]$W,[int]$H,[int]$Size=10,[bool]$Bold=$false,[int]$Color=5263440,[int]$Align=3)
    $c=$script:App.CreateControl($Form,$AC_LABEL,$AC_DETAIL,'','',$X,$Y,$W,$H)
    $c.Caption=$Caption; $c.FontName='Segoe UI'; $c.FontSize=$Size; $c.FontBold=$Bold; $c.ForeColor=$Color; $c.TextAlign=$Align; $c.BackStyle=0
    Release-ComObjectSafe $c
}

function Add-HeaderLabel {
    param([string]$Form,[string]$Caption,[int]$X,[int]$Y,[int]$W,[int]$H)
    $c=$script:App.CreateControl($Form,$AC_LABEL,$AC_HEADER,'','',$X,$Y,$W,$H)
    $c.Caption=$Caption; $c.FontName='Segoe UI'; $c.FontSize=9; $c.FontBold=$true; $c.ForeColor=5051203; $c.TextAlign=3; $c.BackColor=15921906; $c.BackStyle=1
    Release-ComObjectSafe $c
}

function Add-TextBox {
    param([string]$Form,[string]$Name,[string]$Source,[int]$X,[int]$Y,[int]$W,[int]$H,[int]$Size=10,[bool]$Bold=$false,[int]$Align=3)
    $c=$script:App.CreateControl($Form,$AC_TEXTBOX,$AC_DETAIL,'','',$X,$Y,$W,$H)
    $c.Name=$Name
    if ($Source.Length -gt 0) { $c.ControlSource=$Source }
    $c.FontName='Segoe UI'; $c.FontSize=$Size; $c.FontBold=$Bold; $c.TextAlign=$Align
    $c.BackColor=16777215; $c.BorderColor=13816530; $c.SpecialEffect=0
    Release-ComObjectSafe $c
}

function Add-Button {
    param([string]$Form,[string]$Name,[string]$Caption,[int]$X,[int]$Y,[int]$W,[int]$H,[string]$FunctionName,[int]$BackColor=9004835)
    $c=$script:App.CreateControl($Form,$AC_BUTTON,$AC_DETAIL,'','',$X,$Y,$W,$H)
    $c.Name=$Name; $c.Caption=$Caption; $c.FontName='Segoe UI'; $c.FontSize=10; $c.FontBold=$true; $c.ForeColor=16777215; $c.BackColor=$BackColor
    if ($FunctionName.Length -gt 0) { $c.OnClick=('=' + $FunctionName + '()') }
    Release-ComObjectSafe $c
}

function Add-Combo {
    param([string]$Form,[string]$Name,[string]$BoundField,[string]$RowSource,[int]$X,[int]$Y,[int]$W,[int]$H)
    $c=$script:App.CreateControl($Form,$AC_COMBO,$AC_DETAIL,'',$BoundField,$X,$Y,$W,$H)
    $c.Name=$Name; $c.RowSource=$RowSource; $c.ColumnCount=2; $c.ColumnWidths='0cm;5cm'; $c.FontName='Segoe UI'; $c.FontSize=10; $c.TextAlign=3
    Release-ComObjectSafe $c
}

function Add-SubformControl {
    param([string]$Form,[string]$Name,[string]$SourceObject,[int]$X,[int]$Y,[int]$W,[int]$H,[string]$Master='',[string]$Child='')
    $c=$script:App.CreateControl($Form,$AC_SUBFORM,$AC_DETAIL,'','',$X,$Y,$W,$H)
    $c.Name=$Name; $c.SourceObject=$SourceObject
    if ($Master.Length -gt 0) { $c.LinkMasterFields=$Master; $c.LinkChildFields=$Child }
    Release-ComObjectSafe $c
}

function Add-FormHeader {
    param([string]$Form,[string]$Title,[string]$Subtitle='')
    Add-Rectangle $Form 0 0 18000 900 16777215 16777215
    Add-Label $Form $Title 500 180 16500 420 20 $true 5051203 3
    if ($Subtitle.Length -gt 0) { Add-Label $Form $Subtitle 500 600 16500 260 9 $false 7895160 3 }
}

function Create-Tables {
    Invoke-Sql 'CREATE TABLE tblCategories (CategoryID AUTOINCREMENT CONSTRAINT PK_tblCategories PRIMARY KEY, CategoryName TEXT(100) NOT NULL);' 'tblCategories'
    Invoke-Sql 'CREATE TABLE tblProducts (ProductID AUTOINCREMENT CONSTRAINT PK_tblProducts PRIMARY KEY, ProductName TEXT(150) NOT NULL, CategoryID LONG NOT NULL, UnitPrice CURRENCY NOT NULL, StockQty LONG NOT NULL, MinStock LONG NOT NULL, AddedDate DATETIME NOT NULL, IsActive YESNO NOT NULL, Notes LONGTEXT);' 'tblProducts'
    Invoke-Sql 'CREATE TABLE tblInvoices (InvoiceID AUTOINCREMENT CONSTRAINT PK_tblInvoices PRIMARY KEY, InvoiceDate DATETIME NOT NULL, Notes LONGTEXT, InvoiceStatus TEXT(30) NOT NULL);' 'tblInvoices'
    Invoke-Sql 'CREATE TABLE tblInvoiceDetails (InvoiceDetailID AUTOINCREMENT CONSTRAINT PK_tblInvoiceDetails PRIMARY KEY, InvoiceID LONG NOT NULL, ProductID LONG NOT NULL, Quantity LONG NOT NULL, SalePrice CURRENCY NOT NULL);' 'tblInvoiceDetails'
    $script:Stats.Tables=4
    Set-Context 'Field validation rules'
    $script:Db.TableDefs.Item('tblProducts').Fields.Item('ProductName').AllowZeroLength=$false
    $script:Db.TableDefs.Item('tblProducts').Fields.Item('UnitPrice').ValidationRule='>=0'
    $script:Db.TableDefs.Item('tblProducts').Fields.Item('UnitPrice').ValidationText='سعر الوحدة لا يمكن أن يكون سالبًا.'
    $script:Db.TableDefs.Item('tblProducts').Fields.Item('StockQty').ValidationRule='>=0'
    $script:Db.TableDefs.Item('tblProducts').Fields.Item('MinStock').ValidationRule='>=0'
    $script:Db.TableDefs.Item('tblInvoiceDetails').Fields.Item('Quantity').ValidationRule='>0'
    $script:Db.TableDefs.Item('tblInvoiceDetails').Fields.Item('Quantity').ValidationText='الكمية يجب أن تكون أكبر من صفر.'
    $script:Db.TableDefs.Item('tblInvoiceDetails').Fields.Item('SalePrice').ValidationRule='>=0'
    Write-Log 'Field validation rules: OK'
}

function Create-Indexes {
    Invoke-Sql 'CREATE UNIQUE INDEX UX_CategoryName ON tblCategories(CategoryName);' 'UX_CategoryName'
    Invoke-Sql 'CREATE INDEX IX_Products_Category ON tblProducts(CategoryID);' 'IX_Products_Category'
    Invoke-Sql 'CREATE INDEX IX_Products_Name ON tblProducts(ProductName);' 'IX_Products_Name'
    Invoke-Sql 'CREATE INDEX IX_Invoices_Date ON tblInvoices(InvoiceDate);' 'IX_Invoices_Date'
    Invoke-Sql 'CREATE INDEX IX_Details_Invoice ON tblInvoiceDetails(InvoiceID);' 'IX_Details_Invoice'
    Invoke-Sql 'CREATE INDEX IX_Details_Product ON tblInvoiceDetails(ProductID);' 'IX_Details_Product'
}

function Create-Relation {
    param([string]$Name,[string]$PrimaryTable,[string]$ForeignTable,[string]$PrimaryField,[string]$ForeignField)
    Set-Context $Name
    $rel=$script:Db.CreateRelation($Name,$PrimaryTable,$ForeignTable,$DB_REL_UPDATE_CASCADE)
    $fld=$rel.CreateField($PrimaryField); $fld.ForeignName=$ForeignField; $rel.Fields.Append($fld); $script:Db.Relations.Append($rel)
    Release-ComObjectSafe $fld; Release-ComObjectSafe $rel
    $script:Stats.Relationships++
    Write-Log ($Name + ': OK')
}

function Create-Queries {
    Save-Query 'qryInvoiceCalculation' 'SELECT I.InvoiceID AS InvoiceID, I.InvoiceDate AS InvoiceDate, P.ProductName AS ProductName, D.Quantity AS Quantity, D.SalePrice AS SalePrice, [D].[Quantity]*[D].[SalePrice] AS LineTotal FROM (tblInvoices AS I INNER JOIN tblInvoiceDetails AS D ON I.InvoiceID=D.InvoiceID) INNER JOIN tblProducts AS P ON D.ProductID=P.ProductID;'
    Save-Query 'qryTodaySales' 'SELECT * FROM qryInvoiceCalculation WHERE InvoiceDate>=Date() AND InvoiceDate<Date()+1;'
    Save-Query 'qryTodaySalesTotal' 'SELECT Nz(Sum(LineTotal),0) AS DailySales FROM qryTodaySales;'
    Save-Query 'qryTodayQuantity' 'SELECT Nz(Sum(Quantity),0) AS DailyQty FROM qryTodaySales;'
    Save-Query 'qrySalesByProduct' 'SELECT P.ProductID, P.ProductName, Sum(D.Quantity) AS TotalQty, Sum(D.Quantity*D.SalePrice) AS TotalSales FROM tblProducts AS P INNER JOIN tblInvoiceDetails AS D ON P.ProductID=D.ProductID GROUP BY P.ProductID,P.ProductName ORDER BY Sum(D.Quantity*D.SalePrice) DESC;'
    Save-Query 'qryTopProducts' 'SELECT TOP 10 * FROM qrySalesByProduct ORDER BY TotalQty DESC, TotalSales DESC;'
    Save-Query 'qrySoldByProduct' 'SELECT ProductID, Sum(Quantity) AS SoldQty FROM tblInvoiceDetails GROUP BY ProductID;'
    Save-Query 'qryInventory' "SELECT P.ProductID,P.ProductName,C.CategoryName,P.UnitPrice,P.StockQty-Nz(S.SoldQty,0) AS AvailableQty,P.MinStock,IIf(P.StockQty-Nz(S.SoldQty,0)<=0,'نفد المخزون',IIf(P.StockQty-Nz(S.SoldQty,0)<=P.MinStock,'مخزون منخفض','طبيعي')) AS StockStatus,P.IsActive FROM (tblCategories AS C INNER JOIN tblProducts AS P ON C.CategoryID=P.CategoryID) LEFT JOIN qrySoldByProduct AS S ON P.ProductID=S.ProductID ORDER BY P.ProductName;"
    Save-Query 'qryLowStock' "SELECT * FROM qryInventory WHERE AvailableQty<=MinStock ORDER BY AvailableQty,ProductName;"
    Save-Query 'qryRecentSales' 'SELECT TOP 10 I.InvoiceID,I.InvoiceDate,Sum(D.Quantity*D.SalePrice) AS InvoiceTotal FROM tblInvoices AS I INNER JOIN tblInvoiceDetails AS D ON I.InvoiceID=D.InvoiceID GROUP BY I.InvoiceID,I.InvoiceDate ORDER BY I.InvoiceDate DESC,I.InvoiceID DESC;'
    Save-Query 'qryInvoiceTotals' 'SELECT I.InvoiceID,I.InvoiceDate,Sum(D.Quantity) AS TotalQty,Sum(D.Quantity*D.SalePrice) AS InvoiceTotal FROM tblInvoices AS I INNER JOIN tblInvoiceDetails AS D ON I.InvoiceID=D.InvoiceID GROUP BY I.InvoiceID,I.InvoiceDate;'
    Save-Query 'qryDashboardStats' "SELECT DCount('*','tblProducts') AS ProductCount,Nz(DLookup('DailySales','qryTodaySalesTotal'),0) AS DailySales,DCount('*','tblInvoices','InvoiceDate>=Date() AND InvoiceDate<Date()+1') AS TodayInvoices,DCount('*','qryLowStock') AS LowStockCount;"
}

function Load-SampleData {
    $cats=@('مواد غذائية','مشروبات','منظفات','عناية شخصية','أدوات منزلية')
    foreach($c in $cats){ Invoke-Sql ("INSERT INTO tblCategories(CategoryName) VALUES('"+(Escape-SqlText $c)+"');") ('Category '+$c) }
    $products=@(
      @('أرز بسمتي 5 كجم',1,38.5,25,8),@('سكر 2 كجم',1,12,6,8),@('دقيق 5 كجم',1,18.5,14,6),@('زيت نباتي 1.5 لتر',1,16.75,4,6),
      @('مياه معدنية 1.5 لتر',2,2.5,48,12),@('عصير برتقال 1 لتر',2,7.25,9,10),@('مشروب غازي',2,3.5,30,10),@('حليب طويل الأجل',2,5.75,7,8),
      @('مسحوق غسيل 3 كجم',3,32,12,5),@('سائل جلي',3,8.5,3,5),@('منظف أرضيات',3,11,8,4),@('مناديل مطبخ',3,6,18,6),
      @('شامبو',4,14.5,11,5),@('صابون استحمام',4,4,22,8),@('معجون أسنان',4,9,5,6),@('مناديل مبللة',4,10.5,16,5),
      @('أكياس نفايات',5,7.5,13,5),@('إسفنجة تنظيف',5,3.25,2,4),@('ورق ألمنيوم',5,12.5,9,4),@('أكواب ورقية',5,8.75,20,6)
    )
    $i=0
    foreach($p in $products){
      $price=([string]::Format([Globalization.CultureInfo]::InvariantCulture,'{0}',$p[2]))
      Invoke-Sql ("INSERT INTO tblProducts(ProductName,CategoryID,UnitPrice,StockQty,MinStock,AddedDate,IsActive,Notes) VALUES('"+(Escape-SqlText $p[0])+"',"+$p[1]+","+$price+","+$p[3]+","+$p[4]+",Date()-"+($i%17)+",True,'بيانات تجريبية');") ('Product '+($i+1)); $i++
    }
    $invSql=@(
      "INSERT INTO tblInvoices(InvoiceDate,Notes,InvoiceStatus) VALUES(Date()+TimeSerial(9,15,0),'فاتورة اليوم 1','معتمدة');",
      "INSERT INTO tblInvoices(InvoiceDate,Notes,InvoiceStatus) VALUES(Date()+TimeSerial(13,40,0),'فاتورة اليوم 2','معتمدة');",
      "INSERT INTO tblInvoices(InvoiceDate,Notes,InvoiceStatus) VALUES(Date()-1+TimeSerial(18,10,0),'فاتورة أمس','معتمدة');",
      "INSERT INTO tblInvoices(InvoiceDate,Notes,InvoiceStatus) VALUES(Date()-3+TimeSerial(11,30,0),'فاتورة سابقة','معتمدة');",
      "INSERT INTO tblInvoices(InvoiceDate,Notes,InvoiceStatus) VALUES(Date()-7+TimeSerial(16,20,0),'فاتورة سابقة','معتمدة');")
    $n=0; foreach($s in $invSql){$n++; Invoke-Sql $s ('Invoice '+$n)}
    $details=@(@(1,1,2,38.5),@(1,5,6,2.5),@(1,14,3,4),@(2,4,1,16.75),@(2,7,4,3.5),@(2,13,1,14.5),@(3,2,2,12),@(3,9,1,32),@(4,6,3,7.25),@(4,17,2,7.5),@(5,3,1,18.5),@(5,19,2,12.5))
    $n=0; foreach($d in $details){$n++; $price=([string]::Format([Globalization.CultureInfo]::InvariantCulture,'{0}',$d[3])); Invoke-Sql ("INSERT INTO tblInvoiceDetails(InvoiceID,ProductID,Quantity,SalePrice) VALUES("+$d[0]+","+$d[1]+","+$d[2]+","+$price+");") ('InvoiceDetail '+$n)}
    $script:Stats.SampleRecords=42
    Write-Log 'Sample records: 42 (5 categories, 20 products, 5 invoices, 12 detail lines)'
}

function Create-ProductForm {
    $frm=New-BaseForm 'frmProducts' 'إدارة المنتجات' 15000 8000; $frm.RecordSource='tblProducts'; $frm.DefaultView=0; $frm.AllowAdditions=$true; $frm.AllowEdits=$true; $frm.AllowDeletions=$true
    Add-FormHeader 'frmProducts' 'إدارة المنتجات' 'إضافة وتعديل بيانات المنتجات والمخزون'
    Add-Rectangle 'frmProducts' 6500 1200 7600 5000 16777215
    Add-Label 'frmProducts' 'معلومات المنتج' 9800 1450 3600 350 13 $true 9004835
    Add-Label 'frmProducts' 'اسم المنتج' 11100 2100 2200 300; Add-TextBox 'frmProducts' 'txtProductName' 'ProductName' 7600 2050 3300 430
    Add-Label 'frmProducts' 'الفئة' 11100 2700 2200 300; Add-Combo 'frmProducts' 'cboCategory' 'CategoryID' 'SELECT CategoryID,CategoryName FROM tblCategories ORDER BY CategoryName;' 7600 2650 3300 430
    Add-Label 'frmProducts' 'سعر الوحدة' 11100 3300 2200 300; Add-TextBox 'frmProducts' 'txtUnitPrice' 'UnitPrice' 7600 3250 3300 430
    Add-Label 'frmProducts' 'الكمية الأساسية' 11100 3900 2200 300; Add-TextBox 'frmProducts' 'txtStockQty' 'StockQty' 7600 3850 3300 430
    Add-Label 'frmProducts' 'حد التنبيه' 11100 4500 2200 300; Add-TextBox 'frmProducts' 'txtMinStock' 'MinStock' 7600 4450 3300 430
    Add-Label 'frmProducts' 'ملاحظات' 11100 5100 2200 300; Add-TextBox 'frmProducts' 'txtNotes' 'Notes' 7600 5050 3300 780
    Add-Rectangle 'frmProducts' 700 1200 4800 5000 15921906
    Add-Label 'frmProducts' 'الإجراءات' 1500 1500 3200 350 13 $true 9004835
    Add-Button 'frmProducts' 'cmdNew' 'جديد' 1300 2200 3300 500 'NewRecord'; Add-Button 'frmProducts' 'cmdSave' 'حفظ' 1300 2850 3300 500 'SaveRecord'
    Add-Button 'frmProducts' 'cmdDelete' 'حذف' 1300 3500 3300 500 'DeleteCurrentProduct' 4210752; Add-Button 'frmProducts' 'cmdPrev' 'السابق' 1300 4150 1550 500 'PrevRecord'; Add-Button 'frmProducts' 'cmdNext' 'التالي' 3050 4150 1550 500 'NextRecord'
    Add-Button 'frmProducts' 'cmdClose' 'إغلاق' 1300 4800 3300 500 'CloseActiveForm' 7368816
    Close-SaveForm 'frmProducts'; $script:Stats.Forms++
}

function Create-InvoiceDetailsSubform {
    $frm=New-BaseForm 'sfrmInvoiceDetails' 'تفاصيل الفاتورة' 14000 1200; $frm.RecordSource='tblInvoiceDetails'; $frm.DefaultView=1; $frm.NavigationButtons=$false; $frm.RecordSelectors=$false
    $hidden=$script:App.CreateControl('sfrmInvoiceDetails',$AC_TEXTBOX,$AC_DETAIL,'','InvoiceDetailID',13200,100,500,300); $hidden.Name='txtInvoiceDetailID'; $hidden.Visible=$false; Release-ComObjectSafe $hidden
    $c=$script:App.CreateControl('sfrmInvoiceDetails',$AC_COMBO,$AC_DETAIL,'','ProductID',9500,250,3200,430); $c.Name='cboProduct'; $c.RowSource='SELECT ProductID,ProductName,UnitPrice FROM tblProducts WHERE IsActive=True ORDER BY ProductName;'; $c.ColumnCount=3; $c.ColumnWidths='0cm;5cm;0cm'; $c.AfterUpdate='=FillProductPrice()'; Release-ComObjectSafe $c
    Add-TextBox 'sfrmInvoiceDetails' 'txtQuantity' 'Quantity' 7000 250 1700 430; Add-TextBox 'sfrmInvoiceDetails' 'txtSalePrice' 'SalePrice' 4600 250 1900 430; Add-TextBox 'sfrmInvoiceDetails' 'txtLineTotal' '=[Quantity]*[SalePrice]' 1600 250 2400 430 11 $true
    $frm.BeforeUpdate='=ValidateStock()'
    Close-SaveForm 'sfrmInvoiceDetails'; $script:Stats.Subforms++
}

function Create-SalesForm {
    $frm=New-BaseForm 'frmSales' 'تسجيل المبيعات' 16000 9000; $frm.RecordSource='tblInvoices'; $frm.DefaultView=0
    Add-FormHeader 'frmSales' 'تسجيل المبيعات' 'فاتورة متعددة الأصناف مع التحقق من المخزون'
    Add-Rectangle 'frmSales' 700 1200 14600 1150 16777215
    Add-Label 'frmSales' 'رقم الفاتورة' 12600 1450 1900 300; Add-TextBox 'frmSales' 'txtInvoiceID' 'InvoiceID' 10600 1400 1800 430
    Add-Label 'frmSales' 'التاريخ' 7900 1450 1500 300; Add-TextBox 'frmSales' 'txtInvoiceDate' 'InvoiceDate' 5800 1400 1900 430
    Add-Label 'frmSales' 'الحالة' 4300 1450 1500 300; Add-TextBox 'frmSales' 'txtInvoiceStatus' 'InvoiceStatus' 2200 1400 1900 430
    Add-Label 'frmSales' 'الأصناف' 12600 2600 2200 350 13 $true 9004835
    Add-SubformControl 'frmSales' 'subInvoiceDetails' 'Form.sfrmInvoiceDetails' 800 3050 14400 3800 'InvoiceID' 'InvoiceID'
    Add-Rectangle 'frmSales' 8500 7100 6700 1100 15921906
    Add-Label 'frmSales' 'إجمالي الفاتورة' 12500 7350 2300 300 12 $true 9004835
    Add-TextBox 'frmSales' 'txtInvoiceTotal' "=Nz(DSum('[Quantity]*[SalePrice]','tblInvoiceDetails','InvoiceID=' & Nz([InvoiceID],0)),0)" 9000 7250 3200 650 18 $true
    Add-Button 'frmSales' 'cmdNewInvoice' 'فاتورة جديدة' 800 7250 2200 500 'NewRecord'; Add-Button 'frmSales' 'cmdSaveInvoice' 'حفظ' 3200 7250 1700 500 'SaveRecord'; Add-Button 'frmSales' 'cmdPreview' 'معاينة' 5100 7250 1700 500 'PreviewSalesSummary'; Add-Button 'frmSales' 'cmdClose' 'إغلاق' 7000 7250 1200 500 'CloseActiveForm' 7368816
    Close-SaveForm 'frmSales'; $script:Stats.Forms++
}

function Create-QueryListForm {
    param([string]$Name,[string]$Caption,[string]$Query,[string[]]$Fields,[string[]]$Titles,[int[]]$Widths)
    $frm=New-BaseForm $Name $Caption 15000 7600; $frm.RecordSource=$Query; $frm.DefaultView=1; $frm.AllowAdditions=$false; $frm.AllowDeletions=$false; $frm.AllowEdits=$false; $frm.ScrollBars=2
    $script:App.DoCmd.RunCommand($AC_CMD_FORM_HDR_FTR); $frm.Section($AC_HEADER).Height=520
    $x=400; for($i=0;$i -lt $Fields.Count;$i++){ Add-HeaderLabel $Name $Titles[$i] $x 80 $Widths[$i] 330; Add-TextBox $Name ('fld'+$i) $Fields[$i] $x 120 $Widths[$i] 420 9 $false; $x += $Widths[$i]+180 }
    Close-SaveForm $Name; $script:Stats.Forms++
}

function Add-StockConditionalFormatting {
    param([string]$Form,[string]$ControlName)
    Set-Context ($Form + '.' + $ControlName + ' conditional formatting')
    $script:App.DoCmd.OpenForm($Form,$AC_DESIGN)
    $ctl=$script:App.Forms.Item($Form).Controls.Item($ControlName)
    $f1=$ctl.FormatConditions.Add(1,0,"[StockStatus]='نفد المخزون'",''); $f1.BackColor=13421823; $f1.ForeColor=255; $f1.FontBold=$true
    $f2=$ctl.FormatConditions.Add(1,0,"[StockStatus]='مخزون منخفض'",''); $f2.BackColor=10092543; $f2.ForeColor=26367; $f2.FontBold=$true
    Release-ComObjectSafe $f1; Release-ComObjectSafe $f2; Release-ComObjectSafe $ctl
    Close-SaveForm $Form
    Write-Log 'Conditional formatting: OK'
}

function Create-TodaySalesForm {
    $frm=New-BaseForm 'frmTodaySales' 'مبيعات اليوم' 16000 8500
    Add-FormHeader 'frmTodaySales' 'مبيعات اليوم' 'متابعة المبيعات المسجلة خلال اليوم الحالي'
    $cards=@(
      @('عدد فواتير اليوم',"=DCount('*','tblInvoices','InvoiceDate>=Date() AND InvoiceDate<Date()+1')",11300),
      @('إجمالي مبيعات اليوم',"=Nz(DLookup('DailySales','qryTodaySalesTotal'),0)",6500),
      @('إجمالي الكمية',"=Nz(DLookup('DailyQty','qryTodayQuantity'),0)",1700))
    $j=0; foreach($card in $cards){Add-Rectangle 'frmTodaySales' $card[2] 1350 3900 1300 16777215; Add-Label 'frmTodaySales' $card[0] ($card[2]+400) 1550 3100 300 10 $true 5263440; Add-TextBox 'frmTodaySales' ('kpiToday'+$j) $card[1] ($card[2]+550) 1950 2800 520 18 $true; $j++}
    Add-SubformControl 'frmTodaySales' 'subTodaySales' 'Query.qryTodaySales' 900 3200 14200 3800
    Add-Button 'frmTodaySales' 'cmdPrintToday' 'معاينة التقرير' 11200 7350 2800 500 'PreviewTodaySales'; Add-Button 'frmTodaySales' 'cmdCloseToday' 'إغلاق' 8800 7350 2000 500 'CloseActiveForm' 7368816
    Close-SaveForm 'frmTodaySales'; $script:Stats.Forms++
}

function Create-InventoryForm {
    $frm=New-BaseForm 'frmInventory' 'حالة المخزون' 16000 8500
    Add-FormHeader 'frmInventory' 'حالة المخزون' 'المخزون المتاح والتنبيهات حسب الحد الأدنى'
    Add-Label 'frmInventory' 'بحث باسم المنتج' 11900 1450 2500 300 10 $true 5263440; Add-TextBox 'frmInventory' 'txtInventorySearch' '' 7800 1400 3900 430
    Add-Button 'frmInventory' 'cmdInventorySearch' 'بحث' 5900 1400 1600 430 'FilterInventory'; Add-Button 'frmInventory' 'cmdInventoryClear' 'إلغاء الفلتر' 3900 1400 1700 430 'ClearInventoryFilter' 7368816
    Add-SubformControl 'frmInventory' 'subInventory' 'Form.sfrmInventoryList' 800 2300 14400 4800
    Add-Button 'frmInventory' 'cmdLowStockReport' 'تقرير المخزون المنخفض' 11000 7450 3200 500 'PreviewLowStock'; Add-Button 'frmInventory' 'cmdCloseInventory' 'إغلاق' 8800 7450 1900 500 'CloseActiveForm' 7368816
    Close-SaveForm 'frmInventory'; $script:Stats.Forms++
}

function Create-ProductListForm {
    $frm=New-BaseForm 'frmProductList' 'قائمة المنتجات' 16000 8500
    Add-FormHeader 'frmProductList' 'قائمة المنتجات' 'بحث سريع وإدارة الوصول إلى المنتجات'
    Add-Label 'frmProductList' 'اسم المنتج' 11900 1450 2200 300 10 $true 5263440; Add-TextBox 'frmProductList' 'txtProductSearch' '' 7900 1400 3800 430
    Add-Button 'frmProductList' 'cmdProductSearch' 'بحث' 6000 1400 1600 430 'FilterProductList'; Add-Button 'frmProductList' 'cmdProductClear' 'إلغاء الفلتر' 4000 1400 1700 430 'ClearProductFilter' 7368816; Add-Button 'frmProductList' 'cmdAddProduct' 'إضافة منتج' 1200 1400 2200 430 'OpenProductForm'
    Add-SubformControl 'frmProductList' 'subProductList' 'Form.sfrmProductList' 800 2300 14400 4800
    Add-Button 'frmProductList' 'cmdCloseProducts' 'إغلاق' 11900 7450 2300 500 'CloseActiveForm' 7368816
    Close-SaveForm 'frmProductList'; $script:Stats.Forms++
}

function Create-SearchForm {
    $frm=New-BaseForm 'frmSearch' 'البحث' 12000 6000
    Add-FormHeader 'frmSearch' 'البحث' 'بحث في المنتجات أو فتح فاتورة مباشرة'
    Add-Rectangle 'frmSearch' 1500 1500 9000 2900 16777215
    Add-Label 'frmSearch' 'اسم المنتج' 7200 2050 2200 300 11 $true 5263440; Add-TextBox 'frmSearch' 'txtSearchProduct' '' 3500 2000 3400 430
    Add-Button 'frmSearch' 'cmdSearchProduct' 'بحث في المنتجات' 3500 2700 3400 500 'SearchProducts'
    Add-Label 'frmSearch' 'رقم الفاتورة' 7200 3500 2200 300 11 $true 5263440; Add-TextBox 'frmSearch' 'txtSearchInvoice' '' 5200 3450 1700 430
    Add-Button 'frmSearch' 'cmdOpenInvoice' 'فتح الفاتورة' 3500 3450 1500 430 'OpenInvoiceByNumber'
    Add-Button 'frmSearch' 'cmdCloseSearch' 'إغلاق' 4400 4750 3200 500 'CloseActiveForm' 7368816
    Close-SaveForm 'frmSearch'; $script:Stats.Forms++
}

function Create-Dashboard {
    $frm=New-BaseForm 'frmDashboard' 'نظام إدارة مبيعات محل تجاري' 18000 8800
    Add-Rectangle 'frmDashboard' 0 0 3500 8800 5051203 5051203
    Add-Label 'frmDashboard' 'نظام إدارة مبيعات محل تجاري' 4200 250 12800 500 22 $true 5051203
    Add-Label 'frmDashboard' 'Retail Store Sales Management System' 4200 760 12800 300 9 $false 7895160
    Add-TextBox 'frmDashboard' 'txtDashboardDate' '=Format(Date(),"yyyy/mm/dd")' 14500 1130 2300 360 10 $false
    $nav=@(
      @('الرئيسية','GoHome'),@('المنتجات','OpenProductList'),@('إضافة منتج','OpenProductForm'),@('المبيعات','OpenSalesForm'),@('فاتورة جديدة','NewInvoice'),@('مبيعات اليوم','OpenTodaySales'),@('المخزون','OpenInventory'),@('التقارير','PreviewSalesSummary'),@('البحث','OpenSearch'),@('خروج','ExitApplication'))
    $y=1100; $idx=0; foreach($n in $nav){Add-Button 'frmDashboard' ('nav'+$idx) $n[0] 300 $y 2900 460 $n[1] 9004835; $y+=570; $idx++}
    $kpis=@(
      @('إجمالي المنتجات',"=DCount('*','tblProducts')",13600),
      @('مبيعات اليوم',"=Nz(DLookup('DailySales','qryTodaySalesTotal'),0)",10300),
      @('فواتير اليوم',"=DCount('*','tblInvoices','InvoiceDate>=Date() AND InvoiceDate<Date()+1')",7000),
      @('تنبيه المخزون',"=DCount('*','qryLowStock')",3700))
    $i=0; foreach($k in $kpis){Add-Rectangle 'frmDashboard' $k[2] 1650 2850 1450 16777215; Add-Label 'frmDashboard' $k[0] ($k[2]+300) 1880 2250 300 10 $true 5263440; Add-TextBox 'frmDashboard' ('kpi'+$i) $k[1] ($k[2]+420) 2280 2000 600 20 $true; $i++}
    Add-Label 'frmDashboard' 'إجراءات سريعة' 13000 3400 3500 350 13 $true 9004835
    Add-Button 'frmDashboard' 'quickInvoice' 'فاتورة جديدة' 13700 3900 2700 500 'NewInvoice'; Add-Button 'frmDashboard' 'quickProduct' 'إضافة منتج' 10700 3900 2700 500 'OpenProductForm'; Add-Button 'frmDashboard' 'quickToday' 'مبيعات اليوم' 7700 3900 2700 500 'OpenTodaySales'; Add-Button 'frmDashboard' 'quickReport' 'طباعة الملخص' 4700 3900 2700 500 'PreviewSalesSummary'
    Add-Label 'frmDashboard' 'آخر عمليات البيع' 12200 4850 4300 350 13 $true 9004835; Add-SubformControl 'frmDashboard' 'subRecentSales' 'Query.qryRecentSales' 10400 5300 6200 2350
    Add-Label 'frmDashboard' 'تنبيهات المخزون' 5700 4850 4000 350 13 $true 9004835; Add-SubformControl 'frmDashboard' 'subLowStock' 'Query.qryLowStock' 3900 5300 5900 2350
    Add-Button 'frmDashboard' 'cmdAllAlerts' 'عرض جميع التنبيهات' 5300 7850 3000 460 'OpenInventory'
    Close-SaveForm 'frmDashboard'; $script:Stats.Forms++
}

function Create-SimpleReport {
    param([string]$Name,[string]$Caption,[string]$Source,[string[]]$Fields,[string[]]$Labels,[bool]$WithTotal)
    Set-Context $Name
    $r=$script:App.CreateReport(); $temp=$r.Name; $r.RecordSource=$Source; $r.Caption=$Caption; $r.Width=14800; $r.Section($AC_DETAIL).BackColor=16777215
    $script:App.DoCmd.RunCommand($AC_CMD_REPORT_HDR_FTR)
    $header=$script:App.CreateReportControl($temp,$AC_LABEL,$AC_HEADER,'','',500,180,13500,500); $header.Caption=$Caption; $header.FontName='Segoe UI'; $header.FontSize=18; $header.FontBold=$true; $header.TextAlign=3; $header.ForeColor=5051203; Release-ComObjectSafe $header
    $x=400; $w=[Math]::Floor(13700/$Fields.Count)
    for($i=0;$i -lt $Fields.Count;$i++){
      $lab=$script:App.CreateReportControl($temp,$AC_LABEL,$AC_HEADER,'','',$x,800,$w-100,320); $lab.Caption=$Labels[$i]; $lab.FontName='Segoe UI'; $lab.FontSize=9; $lab.FontBold=$true; $lab.TextAlign=3; $lab.BackColor=15921906; Release-ComObjectSafe $lab
      $ctl=$script:App.CreateReportControl($temp,$AC_TEXTBOX,$AC_DETAIL,'',$Fields[$i],$x,150,$w-100,330); $ctl.FontName='Segoe UI'; $ctl.FontSize=9; $ctl.TextAlign=3; $ctl.BorderColor=15132390; Release-ComObjectSafe $ctl; $x+=$w
    }
    if($WithTotal){$tot=$script:App.CreateReportControl($temp,$AC_TEXTBOX,$AC_FOOTER,'','',8500,300,5000,500); $tot.ControlSource='=Sum([LineTotal])'; $tot.FontName='Segoe UI'; $tot.FontSize=14; $tot.FontBold=$true; $tot.TextAlign=3; Release-ComObjectSafe $tot; $lab=$script:App.CreateReportControl($temp,$AC_LABEL,$AC_FOOTER,'','',11800,900,1800,350); $lab.Caption='إجمالي المبيعات'; $lab.FontName='Segoe UI'; $lab.FontBold=$true; $lab.TextAlign=3; Release-ComObjectSafe $lab}
    $script:App.DoCmd.Save($AC_REPORT,$temp); $script:App.DoCmd.Close($AC_REPORT,$temp,$AC_SAVE_YES); $script:App.DoCmd.Rename($Name,$AC_REPORT,$temp); Release-ComObjectSafe $r
    $script:Stats.Reports++; Write-Log ($Name + ': OK')
}

function Create-Reports {
    Create-SimpleReport 'rptSalesSummary' 'ملخص المبيعات' 'qryInvoiceCalculation' @('InvoiceID','InvoiceDate','ProductName','Quantity','SalePrice','LineTotal') @('الفاتورة','التاريخ','المنتج','الكمية','السعر','الإجمالي') $true
    Create-SimpleReport 'rptTodaySales' 'تقرير مبيعات اليوم' 'qryTodaySales' @('InvoiceID','InvoiceDate','ProductName','Quantity','SalePrice','LineTotal') @('الفاتورة','التاريخ','المنتج','الكمية','السعر','الإجمالي') $true
    Create-SimpleReport 'rptInventory' 'تقرير حالة المخزون' 'qryInventory' @('ProductName','CategoryName','AvailableQty','MinStock','StockStatus') @('المنتج','الفئة','المتاح','الحد الأدنى','الحالة') $false
    Create-SimpleReport 'rptLowStock' 'المنتجات منخفضة المخزون' 'qryLowStock' @('ProductName','CategoryName','AvailableQty','MinStock','StockStatus') @('المنتج','الفئة','المتاح','الحد الأدنى','الحالة') $false
}

function Create-VbaModule {
    Set-Context 'modRetailSystem'
    $m=$script:App.CreateModule(); $temp=$m.Name
    $code=@'
Option Compare Database
Option Explicit

Private Function ActiveDataForm() As Form
    On Error Resume Next
    Set ActiveDataForm = Screen.ActiveControl.Parent
    If ActiveDataForm Is Nothing Then Set ActiveDataForm = Screen.ActiveForm
End Function

Public Function OpenFormByName(ByVal n As String) As Boolean
    On Error GoTo EH
    DoCmd.OpenForm n
    OpenFormByName = True
    Exit Function
EH:
    MsgBox Err.Description, vbExclamation, "النظام"
End Function

Public Function GoHome(): OpenFormByName "frmDashboard": End Function
Public Function OpenProductList(): OpenFormByName "frmProductList": End Function
Public Function OpenProductForm(): OpenFormByName "frmProducts": End Function
Public Function OpenSalesForm(): OpenFormByName "frmSales": End Function
Public Function OpenTodaySales(): OpenFormByName "frmTodaySales": End Function
Public Function OpenInventory(): OpenFormByName "frmInventory": End Function
Public Function OpenSearch(): OpenFormByName "frmSearch": End Function
Public Function NewInvoice(): DoCmd.OpenForm "frmSales", , , , acFormAdd: End Function
Public Function NewRecord(): DoCmd.GoToRecord , , acNewRec: End Function
Public Function SaveRecord(): If Screen.ActiveForm.Dirty Then Screen.ActiveForm.Dirty = False: End Function
Public Function PrevRecord(): On Error Resume Next: DoCmd.GoToRecord , , acPrevious: End Function
Public Function NextRecord(): On Error Resume Next: DoCmd.GoToRecord , , acNext: End Function
Public Function CloseActiveForm(): DoCmd.Close acForm, Screen.ActiveForm.Name: End Function

Public Function DeleteCurrentProduct()
    If MsgBox("حذف المنتج الحالي؟", vbYesNo + vbQuestion, "تأكيد") = vbYes Then DoCmd.RunCommand acCmdDeleteRecord
End Function

Public Function PreviewSalesSummary(): DoCmd.OpenReport "rptSalesSummary", acViewPreview: End Function
Public Function PreviewTodaySales(): DoCmd.OpenReport "rptTodaySales", acViewPreview: End Function
Public Function PreviewLowStock(): DoCmd.OpenReport "rptLowStock", acViewPreview: End Function

Public Function ExitApplication()
    If MsgBox("إغلاق النظام؟", vbYesNo + vbQuestion, "تأكيد") = vbYes Then Application.Quit
End Function

Public Function FillProductPrice()
    On Error GoTo EH
    Dim f As Form
    Set f = ActiveDataForm()
    If Not f Is Nothing Then
        If Nz(f!cboProduct, 0) <> 0 Then f!txtSalePrice = f!cboProduct.Column(2)
    End If
    Exit Function
EH:
    MsgBox Err.Description, vbExclamation, "السعر"
End Function

Public Function ValidateStock() As Boolean
    On Error GoTo EH
    Dim f As Form, pid As Long, q As Long, avail As Long, sold As Long
    Set f = ActiveDataForm()
    If f Is Nothing Then Exit Function
    pid = Nz(f!cboProduct, 0)
    q = Nz(f!txtQuantity, 0)
    If pid = 0 Then MsgBox "اختر المنتج أولاً.", vbExclamation: DoCmd.CancelEvent: Exit Function
    If q <= 0 Then MsgBox "الكمية يجب أن تكون أكبر من صفر.", vbExclamation: DoCmd.CancelEvent: Exit Function
    sold = Nz(DSum("Quantity", "tblInvoiceDetails", "ProductID=" & pid), 0)
    avail = Nz(DLookup("StockQty", "tblProducts", "ProductID=" & pid), 0) - sold
    If Not f.NewRecord Then
        If Nz(f!cboProduct.OldValue, 0) = pid Then avail = avail + Nz(f!txtQuantity.OldValue, 0)
    End If
    If q > avail Then
        MsgBox "الكمية المطلوبة أكبر من المخزون المتاح: " & avail, vbCritical, "المخزون"
        DoCmd.CancelEvent
        Exit Function
    End If
    ValidateStock = True
    Exit Function
EH:
    MsgBox Err.Description, vbExclamation, "التحقق من المخزون"
    DoCmd.CancelEvent
End Function

Public Function FilterProductList()
    Dim s As String
    s = Nz(Forms("frmProductList")!txtProductSearch, "")
    With Forms("frmProductList")!subProductList.Form
        If Len(s) > 0 Then .Filter = "ProductName Like '*" & Replace(s, "'", "''") & "*'": .FilterOn = True
    End With
End Function
Public Function ClearProductFilter(): Forms("frmProductList")!txtProductSearch = Null: Forms("frmProductList")!subProductList.Form.FilterOn = False: End Function
Public Function FilterInventory()
    Dim s As String
    s = Nz(Forms("frmInventory")!txtInventorySearch, "")
    With Forms("frmInventory")!subInventory.Form
        If Len(s) > 0 Then .Filter = "ProductName Like '*" & Replace(s, "'", "''") & "*'": .FilterOn = True
    End With
End Function
Public Function ClearInventoryFilter(): Forms("frmInventory")!txtInventorySearch = Null: Forms("frmInventory")!subInventory.Form.FilterOn = False: End Function
Public Function SearchProducts(): DoCmd.OpenForm "frmProductList": Forms("frmProductList")!txtProductSearch = Nz(Forms("frmSearch")!txtSearchProduct, ""): FilterProductList: End Function
Public Function OpenInvoiceByNumber()
    Dim n As Long
    n = Nz(Forms("frmSearch")!txtSearchInvoice, 0)
    If n <= 0 Then MsgBox "أدخل رقم فاتورة صحيح.", vbExclamation: Exit Function
    DoCmd.OpenForm "frmSales", , , "InvoiceID=" & n
End Function
'@
    $m.InsertText($code)
    $script:App.DoCmd.Save($AC_MODULE,$temp); $script:App.DoCmd.Close($AC_MODULE,$temp,$AC_SAVE_YES); $script:App.DoCmd.Rename('modRetailSystem',$AC_MODULE,$temp)
    Release-ComObjectSafe $m
    try { $script:App.DoCmd.RunCommand($AC_CMD_COMPILE_SAVE_ALL); Write-Log 'VBA compile/save: OK' } catch { throw ('VBA compile failed: ' + $_.Exception.Message) }
    Write-Log 'modRetailSystem: OK'
}

function Get-RecordCount { param([string]$Sql) $rs=$script:Db.OpenRecordset($Sql); $v=[int]$rs.Fields.Item(0).Value; $rs.Close(); Release-ComObjectSafe $rs; return $v }

function Verify-ObjectNames {
    param($Collection,[string[]]$Names,[string]$TypeName)
    $existing=@(); for($i=0;$i -lt $Collection.Count;$i++){ $existing += [string]$Collection.Item($i).Name }
    foreach($n in $Names){ if($existing -notcontains $n){ throw ($TypeName+' missing: '+$n) } }
}

function Run-Validation {
    if((Get-RecordCount 'SELECT Count(*) FROM tblProducts WHERE UnitPrice<0 OR StockQty<0 OR MinStock<0;') -ne 0){throw 'Product validation failed.'}
    if((Get-RecordCount 'SELECT Count(*) FROM tblInvoiceDetails WHERE Quantity<=0 OR SalePrice<0;') -ne 0){throw 'Invoice detail validation failed.'}
    if((Get-RecordCount 'SELECT Count(*) FROM qryInvoiceCalculation WHERE LineTotal <> Quantity*SalePrice;') -ne 0){throw 'Line total validation failed.'}
    if((Get-RecordCount 'SELECT Count(*) FROM qryLowStock;') -lt 1){throw 'Expected low-stock sample records were not produced.'}
    Verify-ObjectNames $script:App.CurrentProject.AllForms @('frmDashboard','frmProducts','frmProductList','frmSales','frmTodaySales','frmInventory','frmSearch','sfrmInvoiceDetails','sfrmProductList','sfrmInventoryList') 'Form'
    Verify-ObjectNames $script:App.CurrentProject.AllReports @('rptSalesSummary','rptTodaySales','rptInventory','rptLowStock') 'Report'
    Verify-ObjectNames $script:App.CurrentProject.AllModules @('modRetailSystem') 'Module'
    Write-Log 'Logical validation: PASS'
}

function Backup-ExistingFinal {
    if(Test-Path -LiteralPath $script:FinalDbPath){
        $stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
        $backup=Join-Path $script:OutputDir ('Backup_RetailSalesSystem_'+$stamp+'.accdb')
        Copy-Item -LiteralPath $script:FinalDbPath -Destination $backup -Force
        Write-Log ('Existing database backup: '+$backup)
        Remove-Item -LiteralPath $script:FinalDbPath -Force
    }
}

try {
    Write-Log 'Retail Store Sales Management System - Fixed One-Click Builder v2'
    Write-Log ('Timestamp: '+(Get-Date).ToString('o'))
    Write-Log ('Builder path: '+$script:BuilderDir)
    Write-Log ('PowerShell: '+$PSVersionTable.PSVersion.ToString())
    Write-Log ('Windows: '+[Environment]::OSVersion.VersionString)
    Write-Log ('Process bitness: '+([IntPtr]::Size*8)+'-bit')

    Start-Phase 'PHASE 01 - Environment Check'
    Set-Context 'Access.Application COM'
    try { $script:App=New-Object -ComObject Access.Application } catch { throw 'Microsoft Access COM Automation could not be started. Confirm that the desktop Microsoft Access application is installed. Technical detail: '+$_.Exception.Message }
    if($null -eq $script:App){throw 'Microsoft Access COM Automation returned no application object.'}
    $script:App.Visible=$false
    Write-Log ('Access.Application COM: OK | Version: '+$script:App.Version)

    Start-Phase 'PHASE 02 - Create Database'
    Backup-ExistingFinal
    if(Test-Path -LiteralPath $script:TempDbPath){Remove-Item -LiteralPath $script:TempDbPath -Force}
    Set-Context 'RetailSalesSystem_build.accdb'
    $script:App.NewCurrentDatabase($script:TempDbPath)
    $script:Db=$script:App.CurrentDb()
    if(-not (Test-Path -LiteralPath $script:TempDbPath)){throw 'Access did not create the temporary ACCDB file.'}
    Write-Log ('Database created: '+$script:TempDbPath)

    Start-Phase 'PHASE 03 - Create Tables'; Create-Tables
    Start-Phase 'PHASE 04 - Create Indexes'; Create-Indexes
    Start-Phase 'PHASE 05 - Create Relationships'; Create-Relation 'relCategoriesProducts' 'tblCategories' 'tblProducts' 'CategoryID' 'CategoryID'; Create-Relation 'relInvoicesDetails' 'tblInvoices' 'tblInvoiceDetails' 'InvoiceID' 'InvoiceID'; Create-Relation 'relProductsDetails' 'tblProducts' 'tblInvoiceDetails' 'ProductID' 'ProductID'
    Start-Phase 'PHASE 06 - Create Queries'; Create-Queries
    Start-Phase 'PHASE 07 - Insert Sample Data'; Load-SampleData

    Start-Phase 'PHASE 08 - Create Forms'
    Create-ProductForm
    Create-QueryListForm 'sfrmProductList' 'قائمة المنتجات' 'qryInventory' @('ProductName','CategoryName','AvailableQty','MinStock','StockStatus') @('المنتج','الفئة','المتاح','الحد','الحالة') @(3500,2500,1600,1600,2200); $script:Stats.Forms--; $script:Stats.Subforms++
    Create-QueryListForm 'sfrmInventoryList' 'حالة المخزون' 'qryInventory' @('ProductName','CategoryName','AvailableQty','MinStock','StockStatus') @('المنتج','الفئة','المتاح','الحد','الحالة') @(3500,2500,1600,1600,2200); $script:Stats.Forms--; $script:Stats.Subforms++
    Add-StockConditionalFormatting 'sfrmProductList' 'fld4'; Add-StockConditionalFormatting 'sfrmInventoryList' 'fld4'
    Create-ProductListForm; Create-TodaySalesForm; Create-InventoryForm; Create-SearchForm

    Start-Phase 'PHASE 09 - Create Subforms'; Create-InvoiceDetailsSubform
    Start-Phase 'PHASE 10 - Create Sales and Dashboard'; Create-SalesForm; Create-Dashboard
    Start-Phase 'PHASE 11 - Create Reports'; Create-Reports
    Start-Phase 'PHASE 12 - Create VBA and Compile'; Create-VbaModule

    Start-Phase 'PHASE 13 - Apply Startup Settings'
    Set-DbProperty 'StartupForm' $DB_TEXT 'frmDashboard'; Set-DbProperty 'AppTitle' $DB_TEXT 'نظام إدارة مبيعات محل تجاري'; Set-DbProperty 'StartupShowDBWindow' $DB_BOOLEAN $false; Set-DbProperty 'AllowFullMenus' $DB_BOOLEAN $true; Set-DbProperty 'AllowSpecialKeys' $DB_BOOLEAN $true

    Start-Phase 'PHASE 14 - Validation'; Run-Validation

    Start-Phase 'PHASE 15 - Final Save and Close'
    Release-ComObjectSafe $script:Db; $script:Db=$null
    $script:App.CloseCurrentDatabase(); $script:App.Quit(); Release-ComObjectSafe $script:App; $script:App=$null
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
    Move-Item -LiteralPath $script:TempDbPath -Destination $script:FinalDbPath -Force
    $fi=Get-Item -LiteralPath $script:FinalDbPath
    if($fi.Length -le 0){throw 'Final ACCDB exists but its size is zero.'}
    Write-Log ('Final database: '+$script:FinalDbPath+' | '+$fi.Length+' bytes')

    Start-Phase 'PHASE 16 - Final Reopen Verification'
    $script:App=New-Object -ComObject Access.Application; $script:App.Visible=$false; $script:App.OpenCurrentDatabase($script:FinalDbPath); $script:Db=$script:App.CurrentDb()
    Verify-ObjectNames $script:App.CurrentProject.AllForms @('frmDashboard','frmProducts','frmProductList','frmSales','frmTodaySales','frmInventory','frmSearch','sfrmInvoiceDetails','sfrmProductList','sfrmInventoryList') 'Form'
    Verify-ObjectNames $script:App.CurrentProject.AllReports @('rptSalesSummary','rptTodaySales','rptInventory','rptLowStock') 'Report'
    Verify-ObjectNames $script:App.CurrentProject.AllModules @('modRetailSystem') 'Module'
    $startup=[string]$script:Db.Properties.Item('StartupForm').Value; if($startup -ne 'frmDashboard'){throw 'Startup form verification failed.'}
    $products=Get-RecordCount 'SELECT Count(*) FROM tblProducts;'; if($products -ne 20){throw ('Product sample count mismatch: '+$products)}
    Write-Log 'Final Reopen Test: PASS'
    Write-Log ('Tables: '+$script:Stats.Tables+'/'+$script:Stats.Tables)
    Write-Log ('Relationships: '+$script:Stats.Relationships+'/3')
    Write-Log ('Queries: '+$script:Stats.Queries+'/12')
    Write-Log ('Forms: '+$script:Stats.Forms+'/7')
    Write-Log ('Subforms: '+$script:Stats.Subforms+'/3')
    Write-Log ('Reports: '+$script:Stats.Reports+'/4')
    Write-Log ('Sample Records: '+$script:Stats.SampleRecords)
    Write-Log 'Startup Form: PASS (frmDashboard)'
    Write-Log 'Build Result: SUCCESS'
    $script:BuildSucceeded=$true
}
catch {
    $e=$_.Exception
    Write-Log 'Build Result: FAILED'
    Write-Log ('Phase: '+$script:Phase)
    if($script:CurrentObject.Length -gt 0){Write-Log ('Object: '+$script:CurrentObject)}
    Write-Log ('Error Number/HResult: '+$e.HResult)
    Write-Log ('Description: '+$e.Message)
    Write-Log ('Source: '+$e.Source)
    if($_.InvocationInfo){Write-Log ('Script line: '+$_.InvocationInfo.ScriptLineNumber); Write-Log ('Position: '+$_.InvocationInfo.PositionMessage.Replace([Environment]::NewLine,' '))}
    Stop-AccessSafe
    try { [System.Windows.Forms.MessageBox]::Show("Build failed.`r`nPhase: $script:Phase`r`nObject: $script:CurrentObject`r`n$($e.Message)`r`n`r`nSee BUILD_LOG.txt",'Access Builder',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null } catch {}
    exit 1
}
finally {
    if(-not $script:BuildSucceeded){Stop-AccessSafe}
}

Stop-AccessSafe
try { [System.Windows.Forms.MessageBox]::Show("تم إنشاء نظام إدارة مبيعات محل تجاري بنجاح.`r`n`r`n$script:FinalDbPath",'Access Builder',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null } catch {}
exit 0
