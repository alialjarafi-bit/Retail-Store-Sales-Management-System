@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "BUILDER_DIR=%~dp0"
set "PS_SCRIPT=%BUILDER_DIR%BUILD_PROJECT.ps1"
set "LOG_FILE=%BUILDER_DIR%BUILD_LOG.txt"

if not exist "%PS_SCRIPT%" goto :missing_script

powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%PS_SCRIPT%"
set "BUILD_EXIT=%ERRORLEVEL%"

if "%BUILD_EXIT%"=="0" goto :success

echo.
echo ============================================================
echo BUILD FAILED
if exist "%LOG_FILE%" echo See BUILD_LOG.txt in the builder folder.
echo Exit code: %BUILD_EXIT%
echo ============================================================
echo.
cmd /k "echo Builder stopped after failure. Close this window when finished reviewing the message and BUILD_LOG.txt."
exit /b %BUILD_EXIT%

:missing_script
echo.
echo BUILD FAILED: BUILD_PROJECT.ps1 was not found.
echo Expected: "%PS_SCRIPT%"
echo.
cmd /k "echo Required builder file is missing. Close this window when finished."
exit /b 9009

:success
echo.
echo ============================================================
echo BUILD SUCCESS
echo Database created successfully.
echo Open the ACCDB file in the output folder.
echo ============================================================
echo.
pause
exit /b 0
